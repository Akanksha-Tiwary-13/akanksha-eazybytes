import { io } from "socket.io-client";

export const socket = io({
  path: "/socket.io",
  autoConnect: true,
  transports: ["websocket", "polling"],
});
