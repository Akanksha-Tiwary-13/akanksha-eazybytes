import bcrypt from "bcryptjs";
import { prisma } from "./config/prisma";
import { env } from "./config/env";
import { slugify } from "./utils/slugify";

async function seed() {
  const adminEmail = env.admin.email.toLowerCase();

  const existingAdmin = await prisma.user.findUnique({ where: { email: adminEmail } });
  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash(env.admin.password, 10);
    await prisma.user.create({
      data: { name: env.admin.name, email: adminEmail, passwordHash, role: "ADMIN" },
    });
    console.log(`Created admin user: ${adminEmail}`);
  } else {
    console.log(`Admin user already exists: ${adminEmail}`);
  }

  // A non-admin account, seeded only so the RBAC split (ADMIN vs USER) has
  // something to demonstrate/test against - there's no public signup flow.
  const demoUserEmail = env.demoUser.email.toLowerCase();
  const existingDemoUser = await prisma.user.findUnique({ where: { email: demoUserEmail } });
  if (!existingDemoUser) {
    const passwordHash = await bcrypt.hash(env.demoUser.password, 10);
    await prisma.user.create({
      data: { name: env.demoUser.name, email: demoUserEmail, passwordHash, role: "USER" },
    });
    console.log(`Created demo (non-admin) user: ${demoUserEmail}`);
  } else {
    console.log(`Demo user already exists: ${demoUserEmail}`);
  }

  await prisma.settings.upsert({
    where: { key: "site" },
    update: {},
    create: {
      key: "site",
      siteTitle: "Akanksha",
      tagline: "Full-stack developer, still figuring out the best coffee-to-code ratio",
      aboutText:
        "Hey, I'm Akanksha! I like taking a rough idea and turning it into something people can actually click around and use. Most of my time goes into full-stack web apps — I enjoy the backend logic just as much as getting a UI to feel right. When I'm not coding I'm usually reading up on something new or breaking my own projects on purpose to see how they fail. This site is one of those projects: I built the CMS behind it myself, so I can add a project or write a blog post without touching the code again.",
      email: adminEmail,
      location: "Remote",
      socialLinks: [
        { platform: "GitHub", url: "https://github.com" },
        { platform: "LinkedIn", url: "https://linkedin.com" },
      ],
      themeMode: "dark",
      accentColor: "#6366f1",
    },
  });
  console.log("Seeded site settings");

  const projectCount = await prisma.project.count();
  if (projectCount === 0) {
    const projects = [
      {
        title: "Portfolio CMS",
        summary: "This very site — a portfolio with a content dashboard I built myself.",
        description:
          "You're looking at it right now. I got tired of editing JSX every time I wanted to add a project, so I built a proper CMS behind this site instead: React on the front, Express and MySQL (via Prisma) on the back, with a login-protected dashboard for managing everything. I even wired up Socket.io so that if I update something while you're browsing, it shows up for you without a refresh.",
        techStack: ["React", "TypeScript", "Node.js", "Express", "MySQL", "Prisma"],
        featured: true,
        order: 1,
      },
      {
        title: "Task Tracker API",
        summary: "A REST API for team task management, built to actually handle permissions properly.",
        description:
          "A JWT-secured Express + MySQL API for managing projects, tasks, and comments across a team, with role-based access control so people only see and touch what they're supposed to. I spent a good chunk of time on input validation and test coverage here — it's the kind of project where a sloppy edge case can quietly break someone's whole workflow.",
        techStack: ["Node.js", "Express", "MySQL", "JWT"],
        featured: true,
        order: 2,
      },
      {
        title: "Weather Dashboard",
        summary: "A weather dashboard I built mostly to play with animation.",
        description:
          "This one started as an excuse to learn Framer Motion. It's a React app that pulls live weather data and animates the forecast in, and I made sure it holds up on a phone screen just as well as a desktop — most of my early testing was just resizing the browser window over and over.",
        techStack: ["React", "Tailwind CSS", "Framer Motion"],
        featured: false,
        order: 3,
      },
    ];

    for (const p of projects) {
      await prisma.project.create({ data: { ...p, slug: slugify(p.title) } });
    }
    console.log(`Seeded ${projects.length} projects`);
  }

  const skillCount = await prisma.skill.count();
  if (skillCount === 0) {
    const skills = [
      { name: "JavaScript / TypeScript", category: "Languages", level: 5, order: 1 },
      { name: "React", category: "Frontend", level: 5, order: 1 },
      { name: "Node.js / Express", category: "Backend", level: 4, order: 1 },
      { name: "MySQL / Prisma", category: "Database", level: 4, order: 1 },
      { name: "Tailwind CSS", category: "Frontend", level: 4, order: 2 },
      { name: "Git & GitHub", category: "Tools", level: 5, order: 1 },
    ];
    await prisma.skill.createMany({ data: skills });
    console.log(`Seeded ${skills.length} skills`);
  }

  const postCount = await prisma.blogPost.count();
  if (postCount === 0) {
    const post = {
      title: "Why I Gave My Portfolio Its Own CMS",
      excerpt:
        "I got sick of editing JSX just to update my own portfolio, so I built myself a tiny CMS instead.",
      content:
        "For a while, updating my portfolio meant opening the code, editing a JSX file, rebuilding, and redeploying — for something as small as fixing a typo in a project description. That got old fast, so for this project I built myself an actual CMS: a Node/Express API backed by MySQL, a login-protected dashboard, and a public site that pulls content live instead of having it baked in.\n\nThe part I'm most proud of is probably the smallest one — a thin Socket.io layer that pushes a 'content updated' event whenever I save something in the dashboard. So if you're browsing this site while I'm editing it, whatever I changed just shows up, no refresh needed. It's a small thing, but it made the whole CMS feel less like a form and more like actually talking to the live site.\n\nNext up I want to add image uploads instead of pasting in URLs, but that's a project for another weekend.",
      tags: ["web-dev", "cms", "react"],
      published: true,
      publishedAt: new Date(),
    };
    await prisma.blogPost.create({ data: { ...post, slug: slugify(post.title) } });
    console.log("Seeded 1 blog post");
  }

  console.log("Seed complete.");
}

seed()
  .catch((err) => {
    console.error("Seed failed:", err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
