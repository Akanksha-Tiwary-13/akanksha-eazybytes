import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import { authRouter } from "./routes/auth.routes";
import { projectRouter } from "./routes/project.routes";
import { skillRouter } from "./routes/skill.routes";
import { blogRouter } from "./routes/blog.routes";
import { messageRouter } from "./routes/message.routes";
import { settingsRouter } from "./routes/settings.routes";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler";
import { env } from "./config/env";

export function createApp() {
  const app = express();

  app.use(helmet());
  app.use(cors({ origin: env.corsOrigin, credentials: true }));
  app.use(express.json({ limit: "2mb" }));
  app.use(morgan(env.nodeEnv === "production" ? "combined" : "dev"));

  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

  app.use("/api/auth", authRouter);
  app.use("/api/projects", projectRouter);
  app.use("/api/skills", skillRouter);
  app.use("/api/blog", blogRouter);
  app.use("/api/messages", messageRouter);
  app.use("/api/settings", settingsRouter);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
