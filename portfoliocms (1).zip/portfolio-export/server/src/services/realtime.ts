import type { Server } from "socket.io";

let io: Server | null = null;

export function initRealtime(server: Server): void {
  io = server;
}

export type ContentTopic = "projects" | "skills" | "blog" | "settings" | "messages";

export function broadcastContentUpdate(topic: ContentTopic): void {
  io?.emit("content:updated", { topic, at: new Date().toISOString() });
}
