import nodemailer from "nodemailer";
import { env } from "../config/env";

const transporter = env.smtp.host
  ? nodemailer.createTransport({
      host: env.smtp.host,
      port: env.smtp.port,
      secure: env.smtp.port === 465,
      auth: env.smtp.user ? { user: env.smtp.user, pass: env.smtp.pass } : undefined,
    })
  : null;

export async function sendContactNotification(entry: {
  name: string;
  email: string;
  subject: string;
  message: string;
}): Promise<void> {
  if (!transporter || !env.smtp.notifyTo) {
    console.log(
      `[mailer] SMTP not configured - skipping email notification for message from ${entry.email} (subject: "${entry.subject}")`
    );
    return;
  }

  try {
    await transporter.sendMail({
      from: env.smtp.from,
      to: env.smtp.notifyTo,
      replyTo: entry.email,
      subject: `New portfolio contact: ${entry.subject}`,
      text: `From: ${entry.name} <${entry.email}>\n\n${entry.message}`,
      html: `<p><strong>From:</strong> ${entry.name} (${entry.email})</p><p>${entry.message.replace(/\n/g, "<br/>")}</p>`,
    });
  } catch (err) {
    console.error("[mailer] Failed to send contact notification:", err);
  }
}
