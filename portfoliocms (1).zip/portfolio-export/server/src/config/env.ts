import dotenv from "dotenv";

dotenv.config();

function required(name: string, fallback?: string): string {
  const value = process.env[name] ?? fallback;
  if (value === undefined) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

export const env = {
  port: Number(process.env.PORT ?? 3001),
  nodeEnv: process.env.NODE_ENV ?? "development",
  databaseUrl: required(
    "DATABASE_URL",
    "mysql://portfolio:portfolio_dev_pw@localhost:3306/portfolio_cms"
  ),
  jwtSecret: required("JWT_SECRET", "dev-only-change-me-in-production"),
  jwtExpiresIn: process.env.JWT_EXPIRES_IN ?? "7d",
  corsOrigin: process.env.CORS_ORIGIN ?? "http://localhost:5173",
  admin: {
    name: process.env.ADMIN_NAME ?? "Akanksha",
    email: process.env.ADMIN_EMAIL ?? "akanksha@example.com",
    password: process.env.ADMIN_PASSWORD ?? "ChangeMe123!",
  },
  demoUser: {
    name: process.env.DEMO_USER_NAME ?? "Demo Viewer",
    email: process.env.DEMO_USER_EMAIL ?? "viewer@example.com",
    password: process.env.DEMO_USER_PASSWORD ?? "ViewerOnly123!",
  },
  smtp: {
    host: process.env.SMTP_HOST ?? "",
    port: Number(process.env.SMTP_PORT ?? 587),
    user: process.env.SMTP_USER ?? "",
    pass: process.env.SMTP_PASS ?? "",
    from: process.env.SMTP_FROM ?? "Portfolio Site <no-reply@portfolio.dev>",
    notifyTo: process.env.CONTACT_NOTIFY_EMAIL ?? process.env.ADMIN_EMAIL ?? "",
  },
};
