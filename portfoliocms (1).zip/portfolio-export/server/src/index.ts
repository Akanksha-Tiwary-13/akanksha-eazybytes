import { createServer } from "http";
import { Server } from "socket.io";
import { createApp } from "./app";
import { prisma } from "./config/prisma";
import { initRealtime } from "./services/realtime";
import { env } from "./config/env";

async function main() {
  await prisma.$connect();
  console.log("MySQL connected via Prisma");

  const app = createApp();
  const httpServer = createServer(app);

  const io = new Server(httpServer, {
    cors: { origin: env.corsOrigin, credentials: true },
  });
  initRealtime(io);

  httpServer.listen(env.port, () => {
    console.log(`Portfolio API listening on http://localhost:${env.port}`);
  });
}

main().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
