import { Router } from "express";
import { prisma } from "../config/prisma";
import { requireAuth, requireAdmin } from "../middleware/auth";
import { projectSchema } from "../validation/schemas";
import { ApiError } from "../middleware/errorHandler";
import { slugify } from "../utils/slugify";
import { broadcastContentUpdate } from "../services/realtime";

export const projectRouter = Router();

projectRouter.get("/", async (req, res, next) => {
  try {
    const where = req.query.featured === "true" ? { featured: true } : {};
    const projects = await prisma.project.findMany({
      where,
      orderBy: [{ order: "asc" }, { createdAt: "desc" }],
    });
    res.json(projects);
  } catch (err) {
    next(err);
  }
});

projectRouter.get("/:slug", async (req, res, next) => {
  try {
    const project = await prisma.project.findUnique({ where: { slug: req.params.slug } });
    if (!project) throw new ApiError(404, "Project not found");
    res.json(project);
  } catch (err) {
    next(err);
  }
});

async function uniqueSlug(title: string): Promise<string> {
  const base = slugify(title);
  let slug = base;
  let i = 1;
  while (await prisma.project.findUnique({ where: { slug } })) {
    slug = `${base}-${++i}`;
  }
  return slug;
}

projectRouter.post("/", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const data = projectSchema.parse(req.body);
    const slug = await uniqueSlug(data.title);
    const project = await prisma.project.create({
      data: {
        ...data,
        slug,
        liveUrl: data.liveUrl ?? "",
        repoUrl: data.repoUrl ?? "",
        featured: data.featured ?? false,
        order: data.order ?? 0,
      },
    });
    broadcastContentUpdate("projects");
    res.status(201).json(project);
  } catch (err) {
    next(err);
  }
});

projectRouter.put("/:id", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const data = projectSchema.partial().parse(req.body);
    const existing = await prisma.project.findUnique({ where: { id: req.params.id } });
    if (!existing) throw new ApiError(404, "Project not found");

    const project = await prisma.project.update({ where: { id: req.params.id }, data });
    broadcastContentUpdate("projects");
    res.json(project);
  } catch (err) {
    next(err);
  }
});

projectRouter.delete("/:id", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const existing = await prisma.project.findUnique({ where: { id: req.params.id } });
    if (!existing) throw new ApiError(404, "Project not found");

    await prisma.project.delete({ where: { id: req.params.id } });
    broadcastContentUpdate("projects");
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});
