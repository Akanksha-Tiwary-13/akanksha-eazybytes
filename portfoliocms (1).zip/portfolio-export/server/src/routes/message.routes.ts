import { Router } from "express";
import { prisma } from "../config/prisma";
import { requireAuth, requireAdmin } from "../middleware/auth";
import { messageSchema } from "../validation/schemas";
import { ApiError } from "../middleware/errorHandler";
import { sendContactNotification } from "../services/mailer";
import { broadcastContentUpdate } from "../services/realtime";

export const messageRouter = Router();

messageRouter.post("/", async (req, res, next) => {
  try {
    const data = messageSchema.parse(req.body);
    const entry = await prisma.message.create({ data });
    broadcastContentUpdate("messages");
    void sendContactNotification(data);
    res.status(201).json({ id: entry.id });
  } catch (err) {
    next(err);
  }
});

messageRouter.get("/", requireAuth, requireAdmin, async (_req, res, next) => {
  try {
    const messages = await prisma.message.findMany({ orderBy: { createdAt: "desc" } });
    res.json(messages);
  } catch (err) {
    next(err);
  }
});

messageRouter.patch("/:id/read", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const existing = await prisma.message.findUnique({ where: { id: req.params.id } });
    if (!existing) throw new ApiError(404, "Message not found");

    const message = await prisma.message.update({
      where: { id: req.params.id },
      data: { read: true },
    });
    broadcastContentUpdate("messages");
    res.json(message);
  } catch (err) {
    next(err);
  }
});

messageRouter.delete("/:id", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const existing = await prisma.message.findUnique({ where: { id: req.params.id } });
    if (!existing) throw new ApiError(404, "Message not found");

    await prisma.message.delete({ where: { id: req.params.id } });
    broadcastContentUpdate("messages");
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});
