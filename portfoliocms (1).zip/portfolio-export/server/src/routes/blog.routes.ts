import { Router } from "express";
import jwt from "jsonwebtoken";
import { prisma } from "../config/prisma";
import { requireAuth, requireAdmin, type AuthPayload } from "../middleware/auth";
import { blogPostSchema } from "../validation/schemas";
import { ApiError } from "../middleware/errorHandler";
import { slugify } from "../utils/slugify";
import { broadcastContentUpdate } from "../services/realtime";
import { env } from "../config/env";

export const blogRouter = Router();

function isAdminRequest(req: import("express").Request): boolean {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) return false;
  try {
    const payload = jwt.verify(header.slice("Bearer ".length), env.jwtSecret) as AuthPayload;
    return payload.role === "ADMIN";
  } catch {
    return false;
  }
}

blogRouter.get("/", async (req, res, next) => {
  try {
    const where = isAdminRequest(req) ? {} : { published: true };
    const posts = await prisma.blogPost.findMany({
      where,
      orderBy: [{ publishedAt: "desc" }, { createdAt: "desc" }],
    });
    res.json(posts);
  } catch (err) {
    next(err);
  }
});

blogRouter.get("/:slug", async (req, res, next) => {
  try {
    const post = await prisma.blogPost.findUnique({ where: { slug: req.params.slug } });
    if (!post) throw new ApiError(404, "Post not found");
    if (!post.published && !isAdminRequest(req)) throw new ApiError(404, "Post not found");
    res.json(post);
  } catch (err) {
    next(err);
  }
});

async function uniqueSlug(title: string): Promise<string> {
  const base = slugify(title);
  let slug = base;
  let i = 1;
  while (await prisma.blogPost.findUnique({ where: { slug } })) {
    slug = `${base}-${++i}`;
  }
  return slug;
}

blogRouter.post("/", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const data = blogPostSchema.parse(req.body);
    const slug = await uniqueSlug(data.title);
    const post = await prisma.blogPost.create({
      data: {
        ...data,
        slug,
        coverImageUrl: data.coverImageUrl ?? "",
        published: data.published ?? false,
        publishedAt: data.published ? new Date() : null,
      },
    });
    broadcastContentUpdate("blog");
    res.status(201).json(post);
  } catch (err) {
    next(err);
  }
});

blogRouter.put("/:id", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const data = blogPostSchema.partial().parse(req.body);
    const existing = await prisma.blogPost.findUnique({ where: { id: req.params.id } });
    if (!existing) throw new ApiError(404, "Post not found");

    const publishedAt =
      data.published && !existing.published ? new Date() : existing.publishedAt;

    const post = await prisma.blogPost.update({
      where: { id: req.params.id },
      data: { ...data, publishedAt },
    });
    broadcastContentUpdate("blog");
    res.json(post);
  } catch (err) {
    next(err);
  }
});

blogRouter.delete("/:id", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const existing = await prisma.blogPost.findUnique({ where: { id: req.params.id } });
    if (!existing) throw new ApiError(404, "Post not found");

    await prisma.blogPost.delete({ where: { id: req.params.id } });
    broadcastContentUpdate("blog");
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});
