import { Router } from "express";
import { prisma } from "../config/prisma";
import { requireAuth, requireAdmin } from "../middleware/auth";
import { settingsSchema } from "../validation/schemas";
import { broadcastContentUpdate } from "../services/realtime";

export const settingsRouter = Router();

function toDTO(settings: {
  siteTitle: string;
  tagline: string;
  aboutText: string;
  avatarUrl: string;
  resumeUrl: string;
  email: string;
  location: string;
  socialLinks: unknown;
  themeMode: string;
  accentColor: string;
}) {
  const { themeMode, accentColor, ...rest } = settings;
  return { ...rest, theme: { mode: themeMode, accentColor } };
}

async function getOrCreateSettings() {
  let settings = await prisma.settings.findUnique({ where: { key: "site" } });
  if (!settings) {
    settings = await prisma.settings.create({
      data: {
        key: "site",
        aboutText: "Welcome to my portfolio! Update this bio from the CMS dashboard.",
        socialLinks: [],
      },
    });
  }
  return settings;
}

settingsRouter.get("/", async (_req, res, next) => {
  try {
    const settings = await getOrCreateSettings();
    res.json(toDTO(settings));
  } catch (err) {
    next(err);
  }
});

settingsRouter.put("/", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const data = settingsSchema.parse(req.body);
    await getOrCreateSettings();

    const { theme, ...rest } = data;
    const settings = await prisma.settings.update({
      where: { key: "site" },
      data: {
        ...rest,
        ...(theme ? { themeMode: theme.mode, accentColor: theme.accentColor } : {}),
      },
    });
    broadcastContentUpdate("settings");
    res.json(toDTO(settings));
  } catch (err) {
    next(err);
  }
});
