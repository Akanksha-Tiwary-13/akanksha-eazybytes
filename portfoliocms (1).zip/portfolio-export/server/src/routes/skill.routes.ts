import { Router } from "express";
import { prisma } from "../config/prisma";
import { requireAuth, requireAdmin } from "../middleware/auth";
import { skillSchema } from "../validation/schemas";
import { ApiError } from "../middleware/errorHandler";
import { broadcastContentUpdate } from "../services/realtime";

export const skillRouter = Router();

skillRouter.get("/", async (_req, res, next) => {
  try {
    const skills = await prisma.skill.findMany({ orderBy: [{ category: "asc" }, { order: "asc" }] });
    res.json(skills);
  } catch (err) {
    next(err);
  }
});

skillRouter.post("/", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const data = skillSchema.parse(req.body);
    const skill = await prisma.skill.create({ data: { ...data, order: data.order ?? 0 } });
    broadcastContentUpdate("skills");
    res.status(201).json(skill);
  } catch (err) {
    next(err);
  }
});

skillRouter.put("/:id", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const data = skillSchema.partial().parse(req.body);
    const existing = await prisma.skill.findUnique({ where: { id: req.params.id } });
    if (!existing) throw new ApiError(404, "Skill not found");

    const skill = await prisma.skill.update({ where: { id: req.params.id }, data });
    broadcastContentUpdate("skills");
    res.json(skill);
  } catch (err) {
    next(err);
  }
});

skillRouter.delete("/:id", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const existing = await prisma.skill.findUnique({ where: { id: req.params.id } });
    if (!existing) throw new ApiError(404, "Skill not found");

    await prisma.skill.delete({ where: { id: req.params.id } });
    broadcastContentUpdate("skills");
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});
