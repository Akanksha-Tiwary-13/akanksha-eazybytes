import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

export const projectSchema = z.object({
  title: z.string().min(2).max(120),
  summary: z.string().min(2).max(240),
  description: z.string().min(2),
  techStack: z.array(z.string()).default([]),
  imageUrl: z.string().url().or(z.literal("")).default(""),
  liveUrl: z.string().url().or(z.literal("")).optional(),
  repoUrl: z.string().url().or(z.literal("")).optional(),
  featured: z.boolean().optional(),
  order: z.number().optional(),
});

export const skillSchema = z.object({
  name: z.string().min(1).max(60),
  category: z.string().min(1).max(60),
  level: z.number().min(1).max(5),
  order: z.number().optional(),
});

export const blogPostSchema = z.object({
  title: z.string().min(2).max(160),
  excerpt: z.string().min(2).max(300),
  content: z.string().min(2),
  coverImageUrl: z.string().url().or(z.literal("")).optional(),
  tags: z.array(z.string()).default([]),
  published: z.boolean().optional(),
});

export const messageSchema = z.object({
  name: z.string().min(1).max(120),
  email: z.string().email(),
  subject: z.string().min(1).max(160),
  message: z.string().min(5).max(5000),
});

export const settingsSchema = z.object({
  siteTitle: z.string().min(1).max(120).optional(),
  tagline: z.string().min(1).max(200).optional(),
  aboutText: z.string().min(1).optional(),
  avatarUrl: z.string().url().or(z.literal("")).optional(),
  resumeUrl: z.string().url().or(z.literal("")).optional(),
  email: z.string().email().or(z.literal("")).optional(),
  location: z.string().max(120).optional(),
  socialLinks: z
    .array(z.object({ platform: z.string().min(1), url: z.string().url() }))
    .optional(),
  theme: z
    .object({
      mode: z.enum(["light", "dark"]),
      accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/),
    })
    .optional(),
});
